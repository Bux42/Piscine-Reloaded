#include "get_next_line.h"

int		main(void)
{
	char	*str;
	int		fd1;
	int 	fd2;
	int		fd3;
	int		fd4;

	fd1 = open("file1", O_RDONLY);
	fd2 = open("file2", O_RDONLY);
	fd3 = open("file3", O_RDONLY);
	fd4 = open("file4", O_RDONLY);
	ft_putendl("1");
	get_next_line(fd3, &str);
	ft_putendl(str);
	ft_putendl("2");
	get_next_line(fd4, &str);
	ft_putendl(str);
	ft_putendl("3");
	get_next_line(fd3, &str);
	ft_putendl(str);
	ft_putendl("4");
	get_next_line(fd1, &str);
	ft_putendl(str);
	ft_putendl("5");
	get_next_line(fd3, &str);
	ft_putendl(str);
	ft_putendl("6");
	get_next_line(fd3, &str);
	ft_putendl(str);

	get_next_line(fd4, &str);
	ft_putendl(str);

	get_next_line(fd1, &str);
	ft_putendl(str);

	get_next_line(fd2, &str);
	ft_putendl(str);

	get_next_line(fd3, &str);
	ft_putendl(str);

	get_next_line(fd2, &str);
	ft_putendl(str);

	get_next_line(0, &str);
	ft_putendl(str);

	get_next_line(0, &str);
	ft_putendl(str);


	get_next_line(0, &str);
	ft_putendl(str);

	get_next_line(fd3, &str);
	ft_putendl(str);

	get_next_line(fd4, &str);
	ft_putendl(str);

	get_next_line(fd3, &str);
	ft_putendl(str);

	get_next_line(fd1, &str);
	ft_putendl(str);

	get_next_line(fd3, &str);
	ft_putendl(str);

	get_next_line(fd3, &str);
	ft_putendl(str);

	get_next_line(fd4, &str);
	ft_putendl(str);

	get_next_line(fd1, &str);
	ft_putendl(str);

	get_next_line(fd2, &str);
	ft_putendl(str);

	get_next_line(fd3, &str);
	ft_putendl(str);

	get_next_line(fd2, &str);
	ft_putendl(str);


	return (0);
}